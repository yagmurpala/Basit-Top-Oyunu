﻿using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    public TextMeshProUGUI winText;

    void Start()
    {
        winText.text = ""; // Başlangıçta görünmesin diye void start içine yazdım.
    }

    public void ShowWinMessage()
    {
        winText.text = " Tebrikler akıllı bıdık! Oyunu kazandın! ";
    }
}