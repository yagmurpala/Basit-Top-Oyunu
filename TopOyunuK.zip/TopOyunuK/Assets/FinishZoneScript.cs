using UnityEngine;

public class FinishZoneScript : MonoBehaviour
{
    public GameManager gameManager; // GameManager ba�lant�s�

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            gameManager.ShowWinMessage(); // GameManager �zerinden mesaj� ekrana yazd�r
        }
    }
}