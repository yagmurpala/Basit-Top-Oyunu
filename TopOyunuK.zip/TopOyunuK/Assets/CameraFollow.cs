using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform ball; // Topu takip edecek
    public Vector3 offset = new Vector3(0, 5, -5); 

    void LateUpdate()
    {
        transform.position = ball.position + offset; // Topu takip et
    }
}