using UnityEngine;

public class BallController : MonoBehaviour
{
    public float speed = 3f; // Hareket hızı
    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>(); // Rigidbody bileşenini al
    }

    void Update()
    {
        float moveHorizontal = Input.GetAxis("Horizontal"); // Sağ - Sol
        float moveVertical = Input.GetAxis("Vertical"); // İleri - Geri

        Vector3 movement = new Vector3(-moveHorizontal, 0.0f, -moveVertical); 
        rb.AddForce(movement * speed, ForceMode.Acceleration); // Hareketi uygula
    }
}